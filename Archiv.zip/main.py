# This is a sample Python script.

# Press Umschalt+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
from Menu import Menu

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    menu = Menu()
    while True:
        menu.banner()
        menu.data_query()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
